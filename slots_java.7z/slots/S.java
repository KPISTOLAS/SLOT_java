import java.util.Scanner;

public class S {

    static Float play(Float bal, Float am, int an) {
        int max;
        int min;
        int x1;
        int x2;
        int x3;
        Float fin = 0F;
        if (an == 0) {
            max = 9;
            min = 1;
        } else {
            max = 9;
            min = 5;
        }

        if (bal >= am) {
            fin -= am;
            x1 = (int) Math.floor(Math.random() * (max - min + 1) + min);
            x2 = (int) Math.floor(Math.random() * (max - min + 1) + min);
            x3 = (int) Math.floor(Math.random() * (max - min + 1) + min);
            System.out.println(x1 + " " + x2 + " " + x3);

            if (x1 == x2 && x1 == x3 && x2 == x3) {
                System.out.println("BIG WIN :" + am * 10);
                fin = am * 10;
                return fin;

            } else if (x1 == x2 || x1 == x3 || x2 == x3) {
                System.out.println("WIN :" + am * 2);
                fin += am * 2;
                return fin;
            }
        }
        return fin;

    }

    static int SuperSpin(Float am, int an) {
        int max;
        int min;
        int x1;
        int x2;
        int x3;
        if (an == 0) {
            max = 9;
            min = 3;
        } else {
            max = 9;
            min = 6;
        }
        x1 = (int) Math.floor(Math.random() * (max - min + 1) + min);
        x2 = (int) Math.floor(Math.random() * (max - min + 1) + min);
        x3 = (int) Math.floor(Math.random() * (max - min + 1) + min);
        System.out.println(x1 + " " + x2 + " " + x3);

        if ((x1 == x2 || x1 == x3 || x2 == x3) && x1 == 7) {
            System.out.println("MEGA WIN  50x");
                System.out.println("");
                System.out.println("");
                System.out.println("");
                System.out.println("");
            return 50;
        } else if (x1 == x2 || x1 == x3 || x2 == x3) {
            System.out.println("BIG WIN 20x");
             System.out.println("");
                System.out.println("");
                System.out.println("");
                System.out.println("");
            return 20;

        } else if (x1 == x2 || x1 == x3 || x2 == x3) {
            System.out.println("WIN 10x");
             System.out.println("");
                System.out.println("");
                System.out.println("");
                System.out.println("");
            return 10;
        }

        return 0;
    }

    public static void main(String[] args) {
        try (Scanner myObj = new Scanner(System.in)) {
            System.out.println("Welcome to Slot Masters");
            Float bal;
            int an;
            Float dif = 0F;
            int an_fin;
            int ss;
            int count;
            int t1;
            int tm;

            do {
                System.out.println("Please enter your balance:");
                bal = myObj.nextFloat();
            } while (!(bal >= 0));

            Float am;
            do {
                do {
                    System.out.println("Please enter your bet per spin( 1.0 , 2.0 , 5.0 , 10.0 )");
                    am = myObj.nextFloat();
                } while (!((am == 1.0 || am == 2.0 || am == 5.0 || am == 10.0) && (am <= bal)));

                do {
                    System.out.println("Your bet is: " + am);
                    System.out.println("Manual spin (0) or Power spin double luck , double bet  (1) ?");

                    an = myObj.nextInt();
                } while (!((an == 1 && bal >= 2 * am) || an == 0));

                if (an == 1) {
                    am *= 2;
                }

                do {
                    System.out.println(
                            "Do you want to play Super spin (10 spins collect all multiplier) , price " + am * 100
                                    + " (1) or normal spin(0)");
                    ss = myObj.nextInt();
                } while (!((ss == 1 || ss == 0) && bal >= am * 100));

                if (ss == 0) {
                    dif = (float) play(bal, am, an);
                    bal += dif;
                } else {
                    count = 0;
                    bal = bal - (am * 100);
                    tm = 0;
                    while (count <= 10) {
                        t1 = SuperSpin(am, an);
                        tm += t1;
                        count++;
                    }
                    bal = bal + (tm * am);
                }

                System.out.println("Your balance is :" + bal);
                do {
                    System.out.println("Do you want to replay press 1 .If you want to exit press 0");
                    an_fin = myObj.nextInt();
                } while (!(an_fin == 1 || an_fin == 0));
            } while (an_fin == 1);
        }
        System.out.println("Thank you for playing!!!");
    }

}
